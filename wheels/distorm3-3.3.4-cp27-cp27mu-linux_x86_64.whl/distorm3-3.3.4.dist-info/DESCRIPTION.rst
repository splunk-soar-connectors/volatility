Powerful Disassembler Library For AMD64
by Gil Dabah (distorm@gmail.com)

Python bindings by Mario Vilas (mvilas@gmail.com)

